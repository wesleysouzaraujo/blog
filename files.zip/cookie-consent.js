/**
 * Banner de consentimento de cookies (LGPD).
 *
 * Como funciona:
 *  1. Na primeira visita, mostra o banner perguntando se o usuário aceita
 *     cookies de analytics (Google Fonts é considerado baixo risco e já
 *     carrega sempre, mas Analytics/Pixel só carregam com consentimento).
 *  2. A escolha fica salva em localStorage por 6 meses.
 *  3. Se aceitar, dispara o evento "cookies-accepted" — é esse evento que
 *     o script do Google Analytics (analytics.js, abaixo) escuta para
 *     só então carregar o gtag.js.
 *
 * Requisitos no HTML: nenhum elemento fixo precisa existir, o banner
 * é injetado via JS. Basta incluir este script antes do </body>.
 */
(function () {
  var CONSENT_KEY = 'fitblogpro_cookie_consent';
  var CONSENT_DAYS = 180;

  function getConsent() {
    try {
      var raw = localStorage.getItem(CONSENT_KEY);
      if (!raw) return null;
      var data = JSON.parse(raw);
      if (Date.now() > data.expires) return null;
      return data.value;
    } catch (e) {
      return null;
    }
  }

  function setConsent(value) {
    try {
      localStorage.setItem(
        CONSENT_KEY,
        JSON.stringify({
          value: value,
          expires: Date.now() + CONSENT_DAYS * 24 * 60 * 60 * 1000,
        })
      );
    } catch (e) {
      /* localStorage indisponível (modo privado, etc.) — segue sem salvar */
    }
  }

  function dispatchConsentEvent(accepted) {
    document.dispatchEvent(
      new CustomEvent('cookie-consent-changed', { detail: { accepted: accepted } })
    );
  }

  function buildBanner() {
    var banner = document.createElement('div');
    banner.id = 'cookie-banner';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-label', 'Aviso de cookies');
    banner.style.cssText = [
      'position:fixed', 'bottom:0', 'left:0', 'right:0', 'z-index:9999',
      'background:#0F0F0F', 'color:#fff', 'padding:1rem 1.25rem',
      'display:flex', 'flex-wrap:wrap', 'align-items:center',
      'justify-content:space-between', 'gap:1rem',
      'font-family:Inter, Arial, sans-serif', 'font-size:0.9rem',
      'box-shadow:0 -4px 16px rgba(0,0,0,0.25)'
    ].join(';');

    banner.innerHTML =
      '<p style="margin:0;flex:1;min-width:240px;">' +
      '🍪 Usamos cookies para melhorar sua experiência e medir audiência. ' +
      'Ao continuar navegando, você concorda com nossa ' +
      '<a href="/politica-de-privacidade/" style="color:#E63946;text-decoration:underline;">Política de Privacidade</a>.' +
      '</p>' +
      '<div style="display:flex;gap:0.5rem;flex-shrink:0;">' +
      '<button id="cookie-reject" style="background:transparent;color:#fff;border:1px solid #555;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;">Recusar</button>' +
      '<button id="cookie-accept" style="background:#E63946;color:#fff;border:none;padding:0.5rem 1rem;border-radius:8px;cursor:pointer;font-weight:600;">Aceitar</button>' +
      '</div>';

    document.body.appendChild(banner);

    document.getElementById('cookie-accept').addEventListener('click', function () {
      setConsent(true);
      dispatchConsentEvent(true);
      banner.remove();
    });
    document.getElementById('cookie-reject').addEventListener('click', function () {
      setConsent(false);
      dispatchConsentEvent(false);
      banner.remove();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    var consent = getConsent();
    if (consent === null) {
      buildBanner();
    } else {
      // Consentimento já registrado anteriormente: dispara o evento
      // imediatamente para que o analytics.js saiba se pode carregar.
      dispatchConsentEvent(consent);
    }
  });
})();
