/**
 * Carrega o Google Analytics 4 (gtag.js) SOMENTE após consentimento de
 * cookies, conforme LGPD. Depende de cookie-consent.js estar carregado
 * antes (ele dispara o evento "cookie-consent-changed").
 *
 * TODO antes de publicar: substitua "G-XXXXXXXXXX" pelo seu Measurement ID
 * real do GA4 (Admin > Fluxos de dados > seu fluxo web, no analytics.google.com).
 */
(function () {
  var GA_MEASUREMENT_ID = 'G-XXXXXXXXXX'; // TODO: substituir pelo ID real

  var loaded = false;

  function loadGA() {
    if (loaded || GA_MEASUREMENT_ID.indexOf('XXXX') !== -1) {
      if (GA_MEASUREMENT_ID.indexOf('XXXX') !== -1) {
        console.warn('[analytics] GA_MEASUREMENT_ID não configurado ainda.');
      }
      return;
    }
    loaded = true;

    var script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA_MEASUREMENT_ID;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    window.gtag = function () {
      window.dataLayer.push(arguments);
    };
    window.gtag('js', new Date());
    window.gtag('config', GA_MEASUREMENT_ID, { anonymize_ip: true });
  }

  document.addEventListener('cookie-consent-changed', function (event) {
    if (event.detail && event.detail.accepted) {
      loadGA();
    }
  });
})();
